#######################################
# Connect-N Game
# CS 4341 Project 1
# By Paulo Carvalho and Alex Bennett
#######################################

To run the file, simply give main.py to a python interpreter
Depending on the machine configuration it will also be possible to 
run the file directly.

Ex of running with interpreter (cd in file directory):
	python main.py

Ex of running with Referee (All in same line)
	java -jar Referee-3.jar "./ConnectNV2/pacarvalho_agbennett_project1/main.py" "./ConnectNV2/Oponent/main2.py" 6 7 4 1 2

