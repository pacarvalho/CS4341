CS4341 Project 3
By Alex Bennedict and Paulo Carvalho
Feb 7, 2014

To run the program just run the following command on a computer
that has python installed:

	./main.py trainDataSet.csv outputFile.csv

	Where "trainDataSet.csv" is the input file with the data
	and "outputFile.csv" is the output file (or non-existant)